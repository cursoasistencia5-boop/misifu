package com.example.misifu

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
